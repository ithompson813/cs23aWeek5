-- allow printing to console to aid in debugging
function love.conf(t)
	t.console = true
end